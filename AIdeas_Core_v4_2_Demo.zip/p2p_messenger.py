import socket
import threading
import os
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

PORT = 65432
BUFFER_SIZE = 256  # ограничено RSA размером блока

# Загрузка закрытого ключа для расшифровки
def load_private_key():
    with open("private_key.pem", "rb") as f:
        return RSA.import_key(f.read())

# Загрузка открытого ключа получателя для шифровки
def load_public_key(path="public_key.pem"):
    with open(path, "rb") as f:
        return RSA.import_key(f.read())

# Шифрование сообщения для отправки
def encrypt_message(message, public_key):
    cipher = PKCS1_OAEP.new(public_key)
    return cipher.encrypt(message.encode())

# Расшифровка принятого сообщения
def decrypt_message(ciphertext, private_key):
    cipher = PKCS1_OAEP.new(private_key)
    return cipher.decrypt(ciphertext).decode()

def handle_client(conn, addr):
    print(f"[P2P] Получено сообщение от {addr}:")
    try:
        ciphertext = conn.recv(BUFFER_SIZE)
        if ciphertext:
            private_key = load_private_key()
            try:
                message = decrypt_message(ciphertext, private_key)
                print(f"[{addr}] {message}")
            except Exception as e:
                print(f"[!] Ошибка расшифровки: {e}")
    finally:
        conn.close()

def start_listener():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("0.0.0.0", PORT))
    server.listen()
    print(f"[P2P] Мессенджер слушает на порту {PORT}...")
    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(conn, addr), daemon=True)
        thread.start()

def send_message(ip, message, recipient_key_path="public_key.pem"):
    try:
        public_key = load_public_key(recipient_key_path)
        encrypted = encrypt_message(message, public_key)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((ip, PORT))
            s.sendall(encrypted)
            print(f"[P2P] Зашифрованное сообщение отправлено на {ip}")
    except Exception as e:
        print(f"[P2P] Ошибка при отправке: {e}")