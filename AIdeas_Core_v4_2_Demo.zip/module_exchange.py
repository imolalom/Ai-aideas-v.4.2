import hashlib
import os
import zipfile

def pack_module(module_filename):
    # Создаём архив .aimod с подписью
    archive_name = module_filename.replace(".py", ".aimod")
    sha256 = hashlib.sha256(open(module_filename, "rb").read()).hexdigest()
    with zipfile.ZipFile(archive_name, 'w') as zipf:
        zipf.write(module_filename)
        zipf.writestr("SIGNATURE.txt", sha256)
    print(f"Модуль упакован: {archive_name}")
    return archive_name

def unpack_and_verify(archive_path, destination="./user_modules"):
    os.makedirs(destination, exist_ok=True)
    with zipfile.ZipFile(archive_path, 'r') as zipf:
        files = zipf.namelist()
        if "SIGNATURE.txt" not in files:
            print("Подпись отсутствует.")
            return False
        code_file = [f for f in files if f.endswith(".py")][0]
        signature = zipf.read("SIGNATURE.txt").decode()
        content = zipf.read(code_file)
        computed = hashlib.sha256(content).hexdigest()
        if computed != signature:
            print("Подпись не совпадает! Отказ.")
            return False
        with open(os.path.join(destination, code_file), "wb") as f:
            f.write(content)
        print(f"Модуль {code_file} установлен.")
        return True