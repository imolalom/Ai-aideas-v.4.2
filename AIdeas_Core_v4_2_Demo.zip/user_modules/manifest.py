def handle(user_input):
    if user_input.lower().strip() == "манифест":
        with open("manifest.txt", "r", encoding="utf-8") as f:
            return f.read()
    elif user_input.lower().startswith("закон"):
        try:
            number = int(user_input.split()[1])
            with open("manifest.txt", "r", encoding="utf-8") as f:
                lines = f.readlines()
                return lines[number - 1].strip() if 0 < number <= len(lines) else "Такого закона нет."
        except:
            return "Формат: закон 3 или манифест"
    return None