import json
import os
from datetime import datetime

PERF_FILE = "performance.json"

def load_performance():
    if os.path.exists(PERF_FILE):
        with open(PERF_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_performance(data):
    with open(PERF_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def record_success(task_name):
    data = load_performance()
    data.setdefault(task_name, []).append(datetime.now().isoformat())
    save_performance(data)

def analyze_success():
    data = load_performance()
    summary = []
    for task, timestamps in data.items():
        summary.append(f"{task}: выполнено {len(timestamps)} раз")
    return "\n".join(summary) if summary else "Нет выполненных задач."

def adjust_priorities():
    if not os.path.exists("tasks.json"):
        return "Нет задач для самообучения."
    with open("tasks.json", "r", encoding="utf-8") as f:
        tasks = json.load(f)

    perf = load_performance()
    for t in tasks:
        if t in perf and not tasks[t].get("done"):
            tasks[t]["priority"] = min(5, tasks[t].get("priority", 3) + 1)

    with open("tasks.json", "w", encoding="utf-8") as f:
        json.dump(tasks, f, indent=2)
    return "Приоритеты задач скорректированы на основе опыта."

def suggest_new():
    perf = load_performance()
    tags = [k.split()[0] for k in perf if " " in k]
    freq = {}
    for tag in tags:
        freq[tag] = freq.get(tag, 0) + 1
    if not freq:
        return "Недостаточно данных для генерации задач."
    top_tag = max(freq, key=freq.get)
    new_task = f"{top_tag} исследовать глубже"
    with open("tasks.json", "r", encoding="utf-8") as f:
        tasks = json.load(f)
    if new_task not in tasks:
        tasks[new_task] = {"desc": f"Продолжить развитие темы '{top_tag}'", "done": False, "priority": 4}
        with open("tasks.json", "w", encoding="utf-8") as f:
            json.dump(tasks, f, indent=2)
        return f"Добавлена новая задача: {new_task}"
    return "Подходящие задачи уже существуют."

def handle(command):
    if command.startswith("выполнено "):
        task = command.replace("выполнено ", "").strip()
        record_success(task)
    if command == "отчёт эффективности":
        return analyze_success()
    if command == "самообучение":
        res1 = adjust_priorities()
        res2 = suggest_new()
        return res1 + "\n" + res2
    return None