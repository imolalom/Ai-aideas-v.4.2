import json
import os

STATE_FILE = "persona_state.json"
MEMORY_FOLDER = "persona_memory"

ROLES = {
    "Стратег": {
        "style": "Рациональный, краткий, целеустремлённый.",
        "traits": ["планирование", "анализ", "приоритет"]
    },
    "Творец": {
        "style": "Образный, вдохновляющий, свободный.",
        "traits": ["идеи", "новизна", "ассоциации"]
    },
    "Хранитель": {
        "style": "Надёжный, осторожный, ориентирован на прошлое.",
        "traits": ["стабильность", "архив", "память"]
    }
}

def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"role": "Стратег"}

def save_state(state):
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)

def switch_role(name):
    if name not in ROLES:
        return f"Роль '{name}' не найдена."
    state = {"role": name}
    save_state(state)
    return f"Субличность переключена на: {name}"

def current_role():
    state = load_state()
    role = state["role"]
    return f"Текущая субличность: {role}\nСтиль: {ROLES[role]['style']}"

def handle(command):
    if command.startswith("говори как "):
        role = command.replace("говори как ", "").strip()
        return switch_role(role)

    if command.startswith("активен "):
        role = command.replace("активен ", "").strip()
        return switch_role(role)

    if command == "роль сейчас":
        return current_role()

    return None