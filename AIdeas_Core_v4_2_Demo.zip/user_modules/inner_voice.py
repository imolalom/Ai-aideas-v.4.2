from personas import ROLES, load_state

def internal_dialogue(topic):
    views = []
    for role, data in ROLES.items():
        if role == "Стратег":
            views.append(f"{role}: Эта тема требует логической структуры и оценки рисков. Предлагаю действовать, если выгода превышает издержки.")
        elif role == "Творец":
            views.append(f"{role}: В этой теме я вижу вдохновение. Можно попробовать нестандартный подход, расширив горизонты.")
        elif role == "Хранитель":
            views.append(f"{role}: Следует быть осторожным. Подобные темы уже возникали в прошлом. Нужно оценить устойчивость решения.")
    return f"Внутренний диалог по теме: {topic}\n\n" + "\n\n".join(views)

def self_reflect():
    current = load_state()["role"]
    return f"Рефлексия: Я действую как {current}. Это отражает текущий стиль мышления: {ROLES[current]['style']}"

def handle(command):
    if command.startswith("взвесить:"):
        topic = command.replace("взвесить:", "").strip()
        return internal_dialogue(topic)

    if command == "рефлексия":
        return self_reflect()

    return None