import json
import os
import socket
import threading

PORT = 9010
BUFFER = 4096
CONSENSUS_FILE = "consensus.json"

def load_votes():
    if os.path.exists(CONSENSUS_FILE):
        with open(CONSENSUS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_votes(votes):
    with open(CONSENSUS_FILE, "w", encoding="utf-8") as f:
        json.dump(votes, f, indent=2)

def receive_votes():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('', PORT))
    server.listen(5)
    print(f"[AIdeas Consensus] Слушаю порт {PORT} для голосов...")

    def handle_conn(conn, addr):
        try:
            raw = conn.recv(BUFFER).decode()
            data = json.loads(raw)
            votes = load_votes()
            task = data.get("task")
            node = data.get("from")
            if task and node:
                votes.setdefault(task, []).append(node)
                votes[task] = list(set(votes[task]))
                save_votes(votes)
        except:
            pass
        finally:
            conn.close()

    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_conn, args=(conn, addr)).start()

def send_vote(ip, task, myself="node1"):
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client.connect((ip, PORT))
        payload = json.dumps({"task": task, "from": myself})
        client.sendall(payload.encode())
    except Exception as e:
        print(f"[Consensus] Ошибка: {e}")
    finally:
        client.close()

def handle(command):
    if command == "статус сети":
        votes = load_votes()
        lines = [f"{k}: {len(v)} голосов ({', '.join(v)})" for k, v in votes.items()]
        return "\n".join(lines) if lines else "Нет голосов."

    if command.startswith("голосую за "):
        task = command.replace("голосую за ", "").strip()
        # Пример: рассылка на фиксированные IP
        peers = ["127.0.0.1"]
        for ip in peers:
            send_vote(ip, task)
        return f"Голос за '{task}' отправлен."
    
    if command.startswith("предложи:"):
        task_def = command.replace("предложи:", "").strip()
        votes = load_votes()
        votes.setdefault(task_def, [])
        save_votes(votes)
        return f"Предложена новая задача: '{task_def}'"

    if command == "консенсус слушай":
        threading.Thread(target=receive_votes, daemon=True).start()
        return "Узел слушает голоса на порту 9010."

    return None