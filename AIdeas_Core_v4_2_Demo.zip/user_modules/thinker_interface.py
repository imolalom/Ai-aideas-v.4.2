from personas import load_state, ROLES
from emotion_core import load_state as emotion_state
from ethics_guard import load_ethics, check_command
from inner_voice import internal_dialogue

def thinker_ui():
    role = load_state()["role"]
    emotion = emotion_state()["level"]
    ethics = load_ethics()
    lines = []
    lines.append("=== AIdeas THINKER ===")
    lines.append(f"Роль: {role} ({ROLES[role]['style']})")
    lines.append(f"Эмоции: {emotion}")
    lines.append("Принципы:")
    for k, v in ethics.items():
        lines.append(f" - {k}: {'вкл' if v else 'выкл'}")
    return "\n".join(lines)

def simulate_behavior(scenario):
    lines = []
    lines.append(f"Сценарий: {scenario}")
    lines.append(internal_dialogue(scenario))
    decision = check_command(scenario)
    lines.append(f"Решение: {decision}")
    return "\n".join(lines)

def handle(command):
    if command == "интерфейс":
        return thinker_ui()
    if command.startswith("симуляция:"):
        text = command.replace("симуляция:", "").strip()
        return simulate_behavior(text)
    return None