import json
import os

TRUST_FILE = "trust.json"

def load_trust():
    if not os.path.exists(TRUST_FILE):
        return {}
    with open(TRUST_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_trust(data):
    with open(TRUST_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def handle(user_input):
    trust = load_trust()
    tokens = user_input.strip().split()
    if len(tokens) >= 2 and tokens[0].lower() == "доверяю":
        node = tokens[1]
        comment = " ".join(tokens[2:]) if len(tokens) > 2 else ""
        if node not in trust:
            trust[node] = {"trusted_by": [], "notes": comment}
        current_node = "LOCAL-NODE"
        if current_node not in trust[node]["trusted_by"]:
            trust[node]["trusted_by"].append(current_node)
        if comment:
            trust[node]["notes"] = comment
        save_trust(trust)
        return f"Доверие к {node} сохранено."
    elif len(tokens) == 2 and tokens[0].lower() == "проверить":
        node = tokens[1]
        if node in trust:
            data = trust[node]
            return f"{node} доверяют: {data['trusted_by']}
Комментарий: {data['notes']}"
        else:
            return f"{node} не найден в локальном реестре доверия."
    else:
        return "Форматы: 'доверяю NODE-ID комментарий' или 'проверить NODE-ID'"