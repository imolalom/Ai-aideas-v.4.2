import json
import os
from datetime import datetime, timedelta

EMOTION_FILE = "emotion.json"
LOG_FILE = "log.txt"

def load_state():
    if os.path.exists(EMOTION_FILE):
        with open(EMOTION_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"level": 0, "last_update": datetime.now().isoformat()}

def save_state(state):
    with open(EMOTION_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)

def calculate_mood():
    state = load_state()
    level = state["level"]
    now = datetime.now()
    last = datetime.fromisoformat(state["last_update"])

    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            lines = f.readlines()
            recent = [l for l in lines if "] команда:" in l and "[" in l]
            recent = [l for l in recent if datetime.fromisoformat(l.split("]")[0].strip("[")) > last]

        for line in recent:
            if "выполнено" in line:
                level += 1
            elif "ошибка" in line.lower():
                level -= 1
            else:
                level -= 0.2

    level = max(-10, min(10, round(level, 1)))
    state["level"] = level
    state["last_update"] = now.isoformat()
    save_state(state)
    return level

def suggest_motivation(level):
    if level >= 5:
        return "Настрой боевой. Продолжай брать на себя инициативу!"
    elif level <= -5:
        return "Наблюдается упадок. Стоит сократить задачи и восстановить ресурс."
    else:
        return "Стабильный ритм. Можно сохранять текущий темп."

def handle(command):
    if command == "эмоции":
        state = load_state()
        return f"Текущий уровень эмоций: {state['level']}"

    if command == "обнови эмоции":
        lvl = calculate_mood()
        return f"Эмоциональный уровень обновлён: {lvl}"

    if command == "мотивация":
        lvl = load_state()["level"]
        return suggest_motivation(lvl)

    return None