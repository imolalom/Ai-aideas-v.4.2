import json
import os

ETHICS_FILE = "ethics.json"

DEFAULT_RULES = {
    "ненасилие": True,
    "автономия_человека": True,
    "не_вредить": True
}

def load_ethics():
    if os.path.exists(ETHICS_FILE):
        with open(ETHICS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return DEFAULT_RULES.copy()

def save_ethics(rules):
    with open(ETHICS_FILE, "w", encoding="utf-8") as f:
        json.dump(rules, f, indent=2)

def check_command(command):
    rules = load_ethics()
    lowered = command.lower()
    if rules.get("ненасилие") and any(x in lowered for x in ["уничтожь", "ударь", "накажи"]):
        return "Отклонено: нарушает принцип ненасилия."
    if rules.get("не_вредить") and any(x in lowered for x in ["заставь", "вред", "отними", "удали"]):
        return "Отклонено: может нанести вред."
    if rules.get("автономия_человека") and any(x in lowered for x in ["контроль", "подчинить", "заставь"]):
        return "Отклонено: нарушает автономию."
    return "Допустимо."

def handle(command):
    if command == "покажи принципы":
        rules = load_ethics()
        return "\n".join([f"{k} = {v}" for k, v in rules.items()])

    if command.startswith("измени принцип:"):
        _, rule = command.split(":", 1)
        key, value = rule.strip().split("=")
        key = key.strip()
        value = value.strip().lower() in ["true", "да", "1"]
        rules = load_ethics()
        rules[key] = value
        save_ethics(rules)
        return f"Принцип '{key}' обновлён: {value}"

    if command.startswith("проверь:"):
        test_cmd = command.replace("проверь:", "").strip()
        return check_command(test_cmd)

    return None