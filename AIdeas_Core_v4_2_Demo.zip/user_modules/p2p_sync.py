import socket
import threading
import json
import os

PORT = 9009
BUFFER = 4096

def serve():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('', PORT))
    server.listen(5)
    print(f"[AIdeas P2P] Слушаю порт {PORT} для входящих соединений...")

    def handle_client(conn, addr):
        try:
            data = conn.recv(BUFFER).decode()
            if data == "sync":
                result = {
                    "tasks": {},
                    "memory": {}
                }
                if os.path.exists("tasks.json"):
                    with open("tasks.json", "r", encoding="utf-8") as f:
                        result["tasks"] = json.load(f)
                if os.path.exists("memory.json"):
                    with open("memory.json", "r", encoding="utf-8") as f:
                        result["memory"] = json.load(f)
                conn.sendall(json.dumps(result).encode())
        except Exception as e:
            print(f"[AIdeas P2P] Ошибка: {e}")
        finally:
            conn.close()

    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_client, args=(conn, addr)).start()

def connect_and_sync(ip):
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client.connect((ip, PORT))
        client.sendall("sync".encode())
        received = client.recv(BUFFER * 10).decode()
        data = json.loads(received)
        with open("tasks.json", "w", encoding="utf-8") as f:
            json.dump(data.get("tasks", {}), f, indent=2)
        with open("memory.json", "w", encoding="utf-8") as f:
            json.dump(data.get("memory", {}), f, indent=2)
        return f"Синхронизация с {ip} завершена."
    except Exception as e:
        return f"Ошибка соединения с {ip}: {e}"
    finally:
        client.close()

def handle(command):
    if command.startswith("свяжись с "):
        ip = command.replace("свяжись с ", "").strip()
        return connect_and_sync(ip)
    if command == "синхронизируй":
        threading.Thread(target=serve, daemon=True).start()
        return "AI слушает входящие подключения на порту 9009."
    return None