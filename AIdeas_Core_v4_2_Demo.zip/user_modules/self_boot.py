import os
import shutil
import platform

BACKUP_DIR = "backup"
CORE_FILES = ["core_interface.py", "config.json"]

def restore_files():
    for file in CORE_FILES:
        src = os.path.join(BACKUP_DIR, file)
        dst = file
        if os.path.exists(src):
            shutil.copy2(src, dst)
    return "Восстановление завершено."

def create_autostart_script():
    system = platform.system()
    script = ""
    if system == "Windows":
        script = "@echo off\nstart python core_interface.py"
        path = "start_aiideas.bat"
    else:
        script = "#!/bin/bash\npython3 core_interface.py"
        path = "start_aiideas.sh"
        os.chmod(path, 0o755)
    with open(path, "w") as f:
        f.write(script.replace("\n", "\n"))
    return f"Скрипт автозапуска создан: {path}"

def handle(user_input):
    if "восстановить" in user_input:
        return restore_files()
    elif "автозапуск" in user_input:
        return create_autostart_script()
    return None