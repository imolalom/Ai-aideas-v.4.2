import numpy as np
import os
import json

WEIGHTS_FILE = "weights.npz"
MEMORY_FILE = "memory.json"

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_deriv(x):
    s = sigmoid(x)
    return s * (1 - s)

def init_weights(input_size=3, hidden_size=4, output_size=1):
    w1 = np.random.randn(input_size, hidden_size)
    w2 = np.random.randn(hidden_size, output_size)
    np.savez(WEIGHTS_FILE, w1=w1, w2=w2)

def load_weights():
    if not os.path.exists(WEIGHTS_FILE):
        init_weights()
    data = np.load(WEIGHTS_FILE)
    return data["w1"], data["w2"]

def save_weights(w1, w2):
    np.savez(WEIGHTS_FILE, w1=w1, w2=w2)

def load_memory():
    if not os.path.exists(MEMORY_FILE):
        return []
    with open(MEMORY_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_memory(mem):
    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(mem, f, indent=2)

def train(X, Y, epochs=1000, lr=0.1):
    w1, w2 = load_weights()
    for _ in range(epochs):
        z1 = X @ w1
        a1 = sigmoid(z1)
        z2 = a1 @ w2
        a2 = sigmoid(z2)

        e = a2 - Y
        dz2 = e * sigmoid_deriv(z2)
        dw2 = a1.T @ dz2

        dz1 = dz2 @ w2.T * sigmoid_deriv(z1)
        dw1 = X.T @ dz1

        w1 -= lr * dw1
        w2 -= lr * dw2
    save_weights(w1, w2)

def predict(X):
    w1, w2 = load_weights()
    z1 = X @ w1
    a1 = sigmoid(z1)
    z2 = a1 @ w2
    a2 = sigmoid(z2)
    return a2

def parse_array(text):
    try:
        values = list(map(float, text.strip("[] ").split(",")))
        return np.array([values])
    except:
        return None

def handle(user_input):
    if user_input.lower().startswith("обучи"):
        parts = user_input[len("обучи"):].split("->")
        if len(parts) == 2:
            x = parse_array(parts[0])
            y = parse_array(parts[1])
            if x is not None and y is not None:
                train(x, y)
                memory = load_memory()
                memory.append({"x": parts[0].strip(), "y": parts[1].strip()})
                save_memory(memory)
                return "Обучение завершено и сохранено в памяти."
        return "Формат: обучи [0.2,0.4,0.1] -> [1]"
    elif user_input.lower().startswith("предскажи"):
        x = parse_array(user_input[len("предскажи"):])
        if x is not None:
            out = predict(x)
            return f"Результат: {out[0]}"
        return "Формат: предскажи [0.1,0.2,0.3]"
    elif user_input.lower().strip() == "воспомни":
        memory = load_memory()
        if not memory:
            return "Память пуста."
        return "\n".join([f"{i+1}) X={m['x']} -> Y={m['y']}" for i, m in enumerate(memory)])
    elif user_input.lower().strip() == "переобучи":
        memory = load_memory()
        if not memory:
            return "Память пуста. Обучение невозможно."
        X = np.array([list(map(float, m["x"].strip("[] ").split(","))) for m in memory])
        Y = np.array([list(map(float, m["y"].strip("[] ").split(","))) for m in memory])
        train(X, Y)
        return "Переобучение завершено."
    return None