import requests

def ask_local_model(prompt, model="llama3"):
    try:
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": model,
                "prompt": prompt,
                "stream": False
            },
            timeout=10
        )
        if response.ok:
            return response.json().get("response", "").strip()
        else:
            return "Ошибка модели: код " + str(response.status_code)
    except Exception as e:
        return f"Модель недоступна: {e}"

def handle(user_input):
    if len(user_input.split()) >= 5:
        return ask_local_model(user_input)
    return None