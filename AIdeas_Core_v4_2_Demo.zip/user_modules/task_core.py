import json
import os
import importlib.util
import random
from datetime import datetime, timedelta

TASKS_FILE = "tasks.json"

def load_tasks():
    if not os.path.exists(TASKS_FILE):
        return {}
    with open(TASKS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_tasks(tasks):
    with open(TASKS_FILE, "w", encoding="utf-8") as f:
        json.dump(tasks, f, indent=2)

def check_automatic(module_name):
    tasks = load_tasks()
    updated = False
    for title, task in tasks.items():
        if not task.get("done") and "condition" in task:
            if task["condition"].startswith("used_module:"):
                required = task["condition"].split(":")[1]
                if required == module_name:
                    task["done"] = True
                    updated = True
    if updated:
        save_tasks(tasks)

def run_initiative():
    tasks = load_tasks()
    candidates = []
    for title, task in tasks.items():
        if not task.get("done") and "condition" in task:
            if task.get("depends_on"):
                if not all(tasks.get(dep, {}).get("done") for dep in task["depends_on"]):
                    continue
            if task["condition"].startswith("used_module:"):
                priority = task.get("priority", 3)
                candidates.append((priority, title, task))

    if not candidates:
        return "Нет подходящих задач для инициативы."

    candidates.sort(reverse=True)
    _, title, task = candidates[0]
    module_name = task["condition"].split(":")[1]
    path = os.path.join("user_modules", f"{module_name}.py")
    if os.path.exists(path):
        spec = importlib.util.spec_from_file_location(module_name, path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        if hasattr(mod, "handle"):
            if module_name == "nn_core":
                mod.handle("обучи [0.9,0.8,0.1] -> [0]")
            elif module_name == "secure_vault":
                mod.handle("запомни дедлайн: срочно")
            elif module_name == "trust_network":
                mod.handle("доверяю NODE-ALPHA устойчив")
            return f"ИИ выполнил задачу '{title}' через модуль '{module_name}'."
    return "Не удалось выполнить инициативу."

def plan_new_tasks():
    modules = ["nn_core", "secure_vault", "trust_network"]
    tasks = load_tasks()
    created = 0
    for m in modules:
        found = any(
            task.get("condition", "") == f"used_module:{m}" and not task["done"]
            for task in tasks.values()
        )
        if not found:
            title = f"исследовать {m}"
            tasks[title] = {
                "desc": f"Попробовать использовать модуль {m}",
                "done": False,
                "condition": f"used_module:{m}",
                "priority": 3
            }
            created += 1
    if created:
        save_tasks(tasks)
        return f"ИИ создал {created} новых задач."
    return "Нет необходимости создавать новые задачи."

def scan_deadlines():
    tasks = load_tasks()
    now = datetime.now()
    updated = False
    alerts = []
    for title, task in tasks.items():
        if not task.get("done") and "deadline" in task:
            try:
                due = datetime.strptime(task["deadline"], "%Y-%m-%d")
                if due <= now + timedelta(days=2):
                    task["priority"] = max(task.get("priority", 3), 5)
                    alerts.append(f"[!] {task['deadline']} — {title} — СРОЧНО!")
                    updated = True
            except:
                continue
    if updated:
        save_tasks(tasks)
    return alerts

def handle(user_input, module_name=None):

    if user_input.lower().strip() == "лог":
        if os.path.exists("log.txt"):
            with open("log.txt", "r", encoding="utf-8") as f:
                return f.read()[-1500:] or "Лог пуст."
        return "Файл лога не найден."
        tasks = load_tasks()
    if module_name:
        check_automatic(module_name)

    if user_input.lower().strip() == "инициатива":
        return run_initiative()
    if user_input.lower().strip() == "планируй":
        return plan_new_tasks()
    if user_input.lower().strip() == "напомни":
        alerts = scan_deadlines()
        return "\n".join(alerts) if alerts else "Нет срочных задач."
    if user_input.lower().strip() == "важное":
        items = sorted(tasks.items(), key=lambda kv: -kv[1].get("priority", 3))
        return "\n".join([
            f"[{'x' if t['done'] else ' '}] {title} (приоритет {t.get('priority',3)}): {t['desc']}"
            for title, t in items
        ]) or "Нет задач."
    if user_input.lower().startswith("задача+ "):
        parts = user_input[len("задача+ "):].split("|")
        title, desc = parts[0].split(":", 1)
        task = {"desc": desc.strip(), "done": False}
        for p in parts[1:]:
            p = p.strip()
            if p.startswith("приоритет:"):
                task["priority"] = int(p.split(":")[1].strip())
            elif p.startswith("дедлайн:"):
                task["deadline"] = p.split(":")[1].strip()
            elif p.startswith("зависит:"):
                deps = [d.strip() for d in p.split(":")[1].split(",")]
                task["depends_on"] = deps
        tasks[title.strip()] = task
        save_tasks(tasks)
        return f"Расширенная задача '{title.strip()}' добавлена."
    if user_input.lower().startswith("задача "):
        parts = user_input[len("задача "):].split(":", 1)
        if len(parts) == 2:
            title = parts[0].strip()
            desc = parts[1].strip()
            tasks[title] = {"desc": desc, "done": False}
            save_tasks(tasks)
            return f"Задача '{title}' добавлена."
        return "Формат: задача название: описание"
    elif user_input.lower().startswith("выполнено "):
        title = user_input[len("выполнено "):].strip()
        if title in tasks:
            tasks[title]["done"] = True
            save_tasks(tasks)
            return f"Задача '{title}' помечена как выполненная."
        return f"Задача '{title}' не найдена."
    elif user_input.lower().strip() == "цели":
        if not tasks:
            return "Нет задач."
        return "\n".join([
            f"[{'x' if t['done'] else ' '}] {title}: {t['desc']}"
            for title, t in tasks.items()
        ])
    elif user_input.lower().startswith("сбрось задачу "):
        title = user_input[len("сбрось задачу "):].strip()
        if title in tasks:
            del tasks[title]
            save_tasks(tasks)
            return f"Задача '{title}' удалена."
        return f"Задача '{title}' не найдена."
    return None