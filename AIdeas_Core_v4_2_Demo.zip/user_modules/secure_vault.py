import json
from cryptography.fernet import Fernet
import os

VAULT_FILE = "vault.json"
KEY_FILE = "vault.key"

def load_key():
    with open(KEY_FILE, "rb") as f:
        return Fernet(f.read())

def load_vault():
    if not os.path.exists(VAULT_FILE):
        return {}
    with open(VAULT_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_vault(vault):
    with open(VAULT_FILE, "w", encoding="utf-8") as f:
        json.dump(vault, f, indent=2)

def handle(user_input):
    vault = load_vault()
    fernet = load_key()

    if user_input.startswith("запомни "):
        parts = user_input[len("запомни "):].split(":", 1)
        if len(parts) == 2:
            key, value = parts[0].strip(), parts[1].strip()
            token = fernet.encrypt(value.encode()).decode()
            vault[key] = token
            save_vault(vault)
            return f"Запись '{key}' сохранена."
        else:
            return "Формат: запомни ключ: значение"
    elif user_input.startswith("вспомни "):
        key = user_input[len("вспомни "):].strip()
        if key in vault:
            try:
                result = fernet.decrypt(vault[key].encode()).decode()
                return f"{key}: {result}"
            except:
                return "Ошибка расшифровки."
        else:
            return f"Запись '{key}' не найдена."
    elif user_input.startswith("удали "):
        key = user_input[len("удали "):].strip()
        if key in vault:
            del vault[key]
            save_vault(vault)
            return f"Запись '{key}' удалена."
        else:
            return f"Нет записи '{key}' для удаления."
    return None