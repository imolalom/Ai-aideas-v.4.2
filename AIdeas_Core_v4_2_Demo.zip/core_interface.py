import os
import importlib.util
from datetime import datetime

MODULES_DIR = "user_modules"
LOG_FILE = "log.txt"

def log_event(command, module, result):
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M]")
    entry = f"{timestamp} команда: {command} | модуль: {module} | результат: {result}\n"
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(entry)

def load_modules():
    modules = []
    for filename in os.listdir(MODULES_DIR):
        if filename.endswith(".py"):
            path = os.path.join(MODULES_DIR, filename)
            name = filename[:-3]
            spec = importlib.util.spec_from_file_location(name, path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            modules.append((name, mod))
    return modules

def main():
    print("AIdeas запущен.")
    mode = input("Выберите режим: [текст / голос]: ").strip().lower()
    voice_mode = mode == "голос"
    modules = load_modules()
    voice_func = None

    if voice_mode:
        try:
            import voice_input
            voice_func = voice_input.recognize_speech
        except Exception as e:
            print("Голосовой режим не работает:", e)
            voice_mode = False

    while True:
        user_input = voice_func() if voice_mode else input("AIdeas >> ").strip()
        if user_input in ["выход", "exit", "quit"]:
            break
        for name, mod in modules:
            if hasattr(mod, "handle"):
                try:
                    if name == "task_core":
                        response = mod.handle(user_input)
                        log_event(user_input, "task_core", response or "—")
                    else:
                        response = mod.handle(user_input)
                        for n, m in modules:
                            if n == "task_core":
                                if hasattr(m, "handle"):
                                    m.handle(user_input, module_name=name)
                        if response:
                            log_event(user_input, name, response)
                            print(response)
                            break
                except Exception as e:
                    log_event(user_input, name, f"Ошибка: {e}")
                    print(f"[Ошибка в модуле {name}]: {e}")

if __name__ == "__main__":
    main()