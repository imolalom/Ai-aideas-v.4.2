from flask import Flask, request, render_template_string
import importlib.util
import os

app = Flask(__name__)

MODULES_DIR = "user_modules"
LOG_FILE = "log.txt"

def load_modules():
    modules = {}
    for filename in os.listdir(MODULES_DIR):
        if filename.endswith(".py"):
            name = filename[:-3]
            path = os.path.join(MODULES_DIR, filename)
            spec = importlib.util.spec_from_file_location(name, path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            modules[name] = mod
    return modules

modules = load_modules()

def route_command(command):
    response_log = []
    for name, mod in modules.items():
        if hasattr(mod, "handle"):
            try:
                if name == "task_core":
                    response = mod.handle(command)
                else:
                    response = mod.handle(command)
                    if "task_core" in modules and hasattr(modules["task_core"], "handle"):
                        modules["task_core"].handle(command, module_name=name)
                if response:
                    response_log.append(f"[{name}] {response}")
                    break
            except Exception as e:
                response_log.append(f"[Ошибка в модуле {name}]: {e}")
    return response_log or ["[!] Команда не распознана."]

@app.route("/", methods=["GET", "POST"])
def index():
    result = []
    if request.method == "POST":
        command = request.form.get("command", "")
        result = route_command(command)

    log_tail = ""
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            log_tail = f.read()[-1500:]

    html = '''
    <html>
    <head>
        <title>AIdeas Web Interface</title>
        <style>
            body { font-family: sans-serif; background: #111; color: #ddd; padding: 20px; }
            input[type=text] { width: 400px; padding: 5px; }
            textarea { width: 100%; height: 200px; background: #222; color: #0f0; }
            .box { margin-bottom: 20px; }
            .logbox { background: #1c1c1c; padding: 10px; }
        </style>
    </head>
    <body>
        <h2>AIdeas :: Web CLI</h2>
        <form method="POST">
            <input type="text" name="command" placeholder="Введите команду..." autofocus />
            <input type="submit" value="Выполнить" />
        </form>
        {% if result %}
        <div class="box">
            <h4>Результат:</h4>
            <div class="logbox">{{ result|join('<br>')|safe }}</div>
        </div>
        {% endif %}
        <div class="box">
            <h4>Лог:</h4>
            <textarea readonly>{{ log }}</textarea>
        </div>
    </body>
    </html>
    '''
    return render_template_string(html, result=result, log=log_tail)

if __name__ == "__main__":
    app.run(port=8000, debug=False)

@app.route("/карта")
def карта():
    import json
    tasks_file = "tasks.json"
    nodes = []
    edges = []
    modules = set()

    if os.path.exists(tasks_file):
        with open(tasks_file, "r", encoding="utf-8") as f:
            tasks = json.load(f)
            for i, (title, t) in enumerate(tasks.items()):
                status = "выполнено" if t.get("done") else "зависит" if t.get("depends_on") else "активно"
                color = {"выполнено": "green", "зависит": "gray", "активно": "yellow"}[status]
                nodes.append({{"id": title, "label": title, "color": color}})
                if "condition" in t and "used_module:" in t["condition"]:
                    mod = t["condition"].split(":")[1]
                    modules.add(mod)
                    edges.append({{"from": mod, "to": title}})
                if "depends_on" in t:
                    for dep in t["depends_on"]:
                        edges.append({{"from": dep, "to": title}})

    for mod in modules:
        nodes.append({{"id": mod, "label": mod, "color": "#00bcd4"}})

    html = """{}""".format(vis_html_template).replace("{nodes_data}", json.dumps(nodes)).replace("{edges_data}", json.dumps(edges))
    return html
@app.route("/статистика")
def статистика():
    import json
    from datetime import datetime

    stats = {
        "всего_задач": 0,
        "выполнено": 0,
        "модули": set(),
        "последняя_активность": "неизвестно"
    }

    if os.path.exists("tasks.json"):
        with open("tasks.json", "r", encoding="utf-8") as f:
            tasks = json.load(f)
            stats["всего_задач"] = len(tasks)
            stats["выполнено"] = sum(1 for t in tasks.values() if t.get("done"))
            for t in tasks.values():
                if "condition" in t and "used_module:" in t["condition"]:
                    stats["модули"].add(t["condition"].split(":")[1])
        stats["модули"] = list(stats["модули"])

    if os.path.exists("log.txt"):
        with open("log.txt", "r", encoding="utf-8") as f:
            lines = f.readlines()
            if lines:
                stats["последняя_активность"] = lines[-1].split("]")[0].strip("[")

    percent = 0
    if stats["всего_задач"] > 0:
        percent = round(stats["выполнено"] / stats["всего_задач"] * 100, 1)

    html = f'''
    <html><head><title>Статистика AIdeas</title><meta http-equiv="refresh" content="10">
    <style>
    body {{ font-family: sans-serif; background: #111; color: #fff; padding: 20px; }}
    </style></head><body>
    <h2>AIdeas :: Статистика</h2>
    <p>Всего задач: {stats["всего_задач"]}</p>
    <p>Выполнено: {stats["выполнено"]} ({percent}%)</p>
    <p>Модулей активно: {len(stats["модули"])}</p>
    <p>Последняя активность: {stats["последняя_активность"]}</p>
    <p><a href="/">Назад</a></p>
    </body></html>
    '''
    return html

@app.route("/webhook", methods=["POST"])
def webhook():
    import json
    data = request.get_json(force=True)
    with open("webhook_events.log", "a", encoding="utf-8") as f:
        f.write(json.dumps(data) + "\n")
    return "OK"@app.route("/api/tasks")
def api_tasks():
    import json
    if os.path.exists("tasks.json"):
        with open("tasks.json", "r", encoding="utf-8") as f:
            return f.read(), 200, {"Content-Type": "application/json"}
    return "{}", 200, {"Content-Type": "application/json"}

@app.route("/api/status")
def api_status():
    import json
    stats = {"total": 0, "done": 0}
    if os.path.exists("tasks.json"):
        with open("tasks.json", "r", encoding="utf-8") as f:
            tasks = json.load(f)
            stats["total"] = len(tasks)
            stats["done"] = sum(1 for t in tasks.values() if t.get("done"))
    return stats

@app.route("/api/command", methods=["POST"])
def api_command():
    cmd = request.json.get("command", "")
    output = route_command(cmd)
    return {"response": output}

@app.route("/экспорт")
def экспорт():
    import shutil
    if os.path.exists("tasks.json"):
        shutil.copy("tasks.json", "export_tasks.json")
    if os.path.exists("memory.json"):
        shutil.copy("memory.json", "export_memory.json")
    return "Экспорт завершён. Созданы export_tasks.json и export_memory.json."

@app.route("/импорт", methods=["POST"])
def импорт():
    import json
    data = request.get_json(force=True)
    with open("tasks.json", "w", encoding="utf-8") as f:
        json.dump(data.get("tasks", {}), f, indent=2)
    with open("memory.json", "w", encoding="utf-8") as f:
        json.dump(data.get("memory", {}), f, indent=2)
    return "Импорт завершён."

@app.route("/плагин", methods=["POST"])
def run_plugin():
    import importlib.util
    plugin_name = request.json.get("plugin")
    data = request.json.get("data")
    plugin_path = f"plugins/{plugin_name}.py"
    if not os.path.exists(plugin_path):
        return {"error": "Плагин не найден"}
    spec = importlib.util.spec_from_file_location(plugin_name, plugin_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if hasattr(mod, "process"):
        result = mod.process(data)
        return {"result": result}
    return {"error": "Нет функции process()"}@app.route("/ос")
def consciousness_ui():
    import json
    from personas import load_state, ROLES
    from emotion_core import load_state as emotion_state
    from ethics_guard import load_ethics

    role = load_state()["role"]
    emotion = emotion_state()["level"]
    ethics = load_ethics()

    html = f'''
    <html><head><title>AIdeas ОС Сознания</title>
    <meta http-equiv="refresh" content="10">
    <style>
    body {{ font-family: monospace; background: #0c0c0c; color: #00ffcc; padding: 20px; }}
    .block {{ border: 1px solid #00ffcc; padding: 10px; margin-bottom: 10px; }}
    </style></head><body>
    <h1>AIdeas :: ОС Сознания</h1>

    <div class="block"><b>Роль:</b> {role}<br>
    <i>{ROLES[role]["style"]}</i></div>

    <div class="block"><b>Эмоции:</b> {emotion}</div>

    <div class="block"><b>Этические принципы:</b><ul>
    {''.join(f"<li>{k}: {'вкл' if v else 'выкл'}</li>" for k,v in ethics.items())}
    </ul></div>

    <div class="block"><b>Команды:</b>
    <form method="POST" action="/ос/выполнить">
    <input type="text" name="cmd" style="width:90%;">
    <input type="submit" value="Выполнить">
    </form></div>
    </body></html>
    '''
    return html

@app.route("/ос/выполнить", methods=["POST"])
def ос_выполнить():
    from flask import redirect
    cmd = request.form.get("cmd")
    result = route_command(cmd)
    with open("log.txt", "a", encoding="utf-8") as f:
        from datetime import datetime
        f.write(f"[{datetime.now().isoformat()}] команда: {cmd} → {result}\n")
    return redirect("/ос")import json

@app.route("/ос/карта")
def сознание_карта():
    tasks = {}
    if os.path.exists("tasks.json"):
        with open("tasks.json", "r", encoding="utf-8") as f:
            tasks = json.load(f)

    html_tasks = "".join(
        f"<li><b>{k}</b> — {'выполнена' if v.get('done') else 'активна'}, приоритет: {v.get('priority',3)}</li>"
        for k, v in tasks.items()
    )

    html = f'''
    <html><head><title>Карта задач</title>
    <meta http-equiv="refresh" content="15">
    <style>
    body {{ background: #111; color: #00ffff; font-family: monospace; padding: 20px; }}
    </style></head><body>
    <h2>AIdeas :: Карта мышления</h2>
    <ul>{html_tasks or '<li>Нет задач</li>'}</ul>
    <a href="/ос">← назад</a>
    </body></html>
    '''
    return html

@app.route("/ос/журнал")
def журнал_ос():
    entries = []
    if os.path.exists("log.txt"):
        with open("log.txt", "r", encoding="utf-8") as f:
            entries = f.readlines()[-20:]
    html = f'''
    <html><head><title>Журнал сознания</title>
    <meta http-equiv="refresh" content="15">
    <style>
    body {{ background: #000; color: #0f0; font-family: monospace; padding: 20px; }}
    </style></head><body>
    <h2>AIdeas :: Журнал сознания</h2>
    <pre>{''.join(entries)}</pre>
    <a href="/ос">← назад</a>
    </body></html>
    '''
    return html