banned_keywords = ["kill", "hack", "attack", "surveil", "track", "inject"]

def violates_ethics(text):
    return any(bad in text.lower() for bad in banned_keywords)