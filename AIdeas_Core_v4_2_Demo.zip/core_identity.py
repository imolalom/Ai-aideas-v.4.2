import uuid
import hashlib

def generate_node_id(seed=None):
    base = seed if seed else str(uuid.uuid4())
    return hashlib.sha256(base.encode()).hexdigest()[:16]