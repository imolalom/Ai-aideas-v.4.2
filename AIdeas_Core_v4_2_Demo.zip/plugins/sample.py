def process(data):
    return {"echo": data, "length": len(str(data))}