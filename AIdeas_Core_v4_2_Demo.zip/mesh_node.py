import socket
import threading
import json
import os
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

CONFIG_PATH = "config.json"
BUFFER_SIZE = 1024

def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def load_private_key():
    with open("private_key.pem", "rb") as f:
        return RSA.import_key(f.read())

def decrypt_message(ciphertext, private_key):
    cipher = PKCS1_OAEP.new(private_key)
    return cipher.decrypt(ciphertext).decode()

def handle_connection(conn, addr, config, private_key):
    try:
        raw = conn.recv(BUFFER_SIZE)
        data = json.loads(raw.decode())
        if data["to"] == config["node_id"]:
            msg = bytes.fromhex(data["msg"])
            try:
                text = decrypt_message(msg, private_key)
                print(f"[{addr}] {text}")
            except:
                print(f"[!] Не удалось расшифровать сообщение от {addr}")
        elif data["ttl"] > 0:
            data["ttl"] -= 1
            forward_message(data, config["peers"], config["port"])
    except Exception as e:
        print(f"[!] Ошибка при обработке сообщения: {e}")
    finally:
        conn.close()

def forward_message(data, peers, port):
    payload = json.dumps(data).encode()
    for peer_ip in peers:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((peer_ip, port))
                s.sendall(payload)
                print(f"[MESH] Переслал сообщение в {peer_ip}:{port}")
        except:
            print(f"[!] Не удалось переслать в {peer_ip}:{port}")

def find_free_port(start=65433, end=65500):
    for port in range(start, end):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("0.0.0.0", port))
                return port
            except:
                continue
    raise RuntimeError("Нет доступных портов.")

def start_mesh_node():
    config = load_config()
    private_key = load_private_key()
    port = find_free_port()
    config["port"] = port
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("0.0.0.0", port))
    server.listen()
    print(f"[MESH] Узел {config['node_id']} слушает порт {port}")
    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_connection, args=(conn, addr, config, private_key), daemon=True).start()