import os
import importlib.util
import threading
from core_ethics import violates_ethics
from core_services import legal_advice, trade_support, survival_guide
from p2p_messenger import send_message, start_listener

# Автозагрузка пользовательских модулей
def load_user_modules(directory="user_modules"):
    modules = {}
    if not os.path.isdir(directory):
        return modules
    for filename in os.listdir(directory):
        if filename.endswith(".py"):
            path = os.path.join(directory, filename)
            module_name = filename[:-3]
            spec = importlib.util.spec_from_file_location(module_name, path)
            module = importlib.util.module_from_spec(spec)
            try:
                spec.loader.exec_module(module)
                modules[module_name] = module
                print(f"Модуль загружен: {module_name}")
            except Exception as e:
                print(f"Ошибка при загрузке {module_name}: {e}")
    return modules

def launch():
    print("AIdeas v0.5 — Агент с авто-запуском P2P-мессенджера.")
    # Запуск прослушивания входящих сообщений
    threading.Thread(target=start_listener, daemon=True).start()
    
    user_modules = load_user_modules()
    while True:
        user_input = input("> ")
        if user_input.lower() in ["exit", "quit"]:
            break
        if violates_ethics(user_input):
            print("Запрос нарушает базовые принципы.")
        elif user_input.startswith("send "):
            parts = user_input.split(" ", 2)
            if len(parts) < 3:
                print("Формат: send <ip> <message>")
            else:
                ip, message = parts[1], parts[2]
                send_message(ip, message)
        elif "legal" in user_input:
            print(legal_advice(user_input))
        elif "trade" in user_input:
            print(trade_support())
        elif "survive" in user_input:
            topic = user_input.split(" ")[-1]
            print(survival_guide(topic))
        else:
            handled = False
            for name, mod in user_modules.items():
                if hasattr(mod, "handle"):
                    response = mod.handle(user_input)
                    if response:
                        print(f"[{name}]: {response}")
                        handled = True
                        break
            if not handled:
                print("Я не знаю этого запроса. Попробуй 'legal', 'trade', 'survive', или 'send <ip> <message>'.")